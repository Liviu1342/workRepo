using UiPath.CodedWorkflows;

namespace UiPath.CodedWorkflows
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new[]{};
        }
    }
}