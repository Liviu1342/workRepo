function verbose(){
  alert("Injection OK");
}