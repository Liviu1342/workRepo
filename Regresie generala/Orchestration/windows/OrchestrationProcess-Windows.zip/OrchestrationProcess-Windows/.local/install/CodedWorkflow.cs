using UiPath.CodedWorkflows;

namespace OrchestrationProcessWindows
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}