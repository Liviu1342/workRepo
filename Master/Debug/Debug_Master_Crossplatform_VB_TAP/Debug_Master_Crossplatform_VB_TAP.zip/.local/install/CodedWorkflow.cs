using UiPath.CodedWorkflows;

namespace Debug_Master_Crossplatform_VB_TAP
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}