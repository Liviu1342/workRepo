using System;
using System.Collections.Generic;

// NOTICE: The Coded Automations feature is available as a preview feature and APIs may be subject to change. 
//         No warranty or technical support is provided for this preview feature.
//         Missing features or encountering bugs? Please click the feedback button in the top-right corner and let us know!
// Please delete these comments after you've read and acknowledged them. For more information, please visit the documentation over at https://docs.uipath.com/studio/lang-en/v2023.10/docs/coded-automations.
namespace Debug_Master_Windows_CS_TAP
{
    public enum PetTypeEnum
    {
        Dog,
        Cat,
        Parrot,
        Hamster,
        GunieaPig,
        HummingBird,
        Iguana,
        Turtle,
        Farret,
        Rabbit
    }
    
    public enum DogSizeEnum
    {
        Small,
        Medium,
        Large,
        ExtraLarge
    }
    
    public enum PetGenderEnum
    {
        Male,
        Female,
        Hermaphrodite,
        Asexual
    }
}