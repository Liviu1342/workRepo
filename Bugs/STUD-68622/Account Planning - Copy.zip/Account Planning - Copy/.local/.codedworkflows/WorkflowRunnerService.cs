using System;
using System.Net.Http;
using System.Threading.Tasks;
using GetInformationForCompany;
using Newtonsoft.Json;
using UiPath.CodedWorkflows;
using UiPath.Robot.Activities.Api;
using System.Collections.Generic;
using UiPath.Activities.Contracts;

namespace GetInformationForCompany
{
    public class WorkflowRunnerService
    {
        private readonly Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> _runWorkflowHandler;
        public WorkflowRunnerService(Func<string, IDictionary<string, object>, TimeSpan?, bool, InvokeTargetSession, IDictionary<string, object>> runWorkflowHandler)
        {
            _runWorkflowHandler = runWorkflowHandler;
        }

        /// <summary>
        /// Invokes the Main.xaml
        /// </summary>
        public string Main(string Account_Name)
        {
            var result = _runWorkflowHandler(@"Main.xaml", new Dictionary<string, object>{{"Account_Name", Account_Name}}, default, default, default);
            return (string)result["resultMessage"];
        }

        /// <summary>
        /// Invokes the CallLLMGateway.cs
        /// </summary>
        public (string response, string error) CallLLMGateway(string accessToken, string resourceUrl, string organizationId, string tenantId, string systemMessage, string userMessage)
        {
            var result = _runWorkflowHandler(@"CallLLMGateway.cs", new Dictionary<string, object>{{"accessToken", accessToken}, {"resourceUrl", resourceUrl}, {"organizationId", organizationId}, {"tenantId", tenantId}, {"systemMessage", systemMessage}, {"userMessage", userMessage}}, default, default, default);
            return ((string)result["response"], (string)result["error"]);
        }

        /// <summary>
        /// Invokes the GetUserInfo.cs
        /// </summary>
        public (string accessToken, string resourceUrl, string tenantId, string organizationId) GetUserInfo()
        {
            var result = _runWorkflowHandler(@"GetUserInfo.cs", new Dictionary<string, object>{}, default, default, default);
            return ((string)result["accessToken"], (string)result["resourceUrl"], (string)result["tenantId"], (string)result["organizationId"]);
        }
    }
}