using System;
using System.Activities;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Utils;
using System.Runtime;
using System.Threading.Tasks;
using GetInformationForCompany;
using UiPath.Robot.Activities.Api;

namespace GetInformationForCompany
{
    public class GetUserInfoActivity : System.Activities.Activity
    {
        public OutArgument<string> accessToken { get; set; }

        public OutArgument<string> resourceUrl { get; set; }

        public OutArgument<string> tenantId { get; set; }

        public OutArgument<string> organizationId { get; set; }

        public GetUserInfoActivity()
        {
            this.Implementation = () =>
            {
                return new GetUserInfoActivityChild()
                {accessToken = (this.accessToken == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "accessToken") : (OutArgument<string>)Argument.CreateReference((Argument)this.accessToken, "accessToken")), resourceUrl = (this.resourceUrl == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "resourceUrl") : (OutArgument<string>)Argument.CreateReference((Argument)this.resourceUrl, "resourceUrl")), tenantId = (this.tenantId == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "tenantId") : (OutArgument<string>)Argument.CreateReference((Argument)this.tenantId, "tenantId")), organizationId = (this.organizationId == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "organizationId") : (OutArgument<string>)Argument.CreateReference((Argument)this.organizationId, "organizationId")), };
            };
        }
    }

    internal class GetUserInfoActivityChild : UiPath.CodedWorkflows.AsyncTaskCodedWorkflowActivity
    {
        public OutArgument<string> accessToken { get; set; }

        public OutArgument<string> resourceUrl { get; set; }

        public OutArgument<string> tenantId { get; set; }

        public OutArgument<string> organizationId { get; set; }

        public System.Collections.Generic.IDictionary<string, object> newResult { get; set; }

        public GetUserInfoActivityChild()
        {
            DisplayName = "GetUserInfo";
        }

        protected override async System.Threading.Tasks.Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, System.Threading.CancellationToken cancellationToken)
        {
            var codedWorkflow = new global::UiPathSalesPlays.GetUserInfo();
            CodedWorkflowHelper.Initialize(codedWorkflow, new UiPath.CodedWorkflows.Utils.CodedWorkflowsFeatureChecker(new System.Collections.Generic.List<string>()
            {UiPath.CodedWorkflows.Utils.CodedWorkflowsFeatures.AsyncEntrypoints}), context);
            var result = await System.Threading.Tasks.Task.Run(() => CodedWorkflowHelper.RunWithExceptionHandlingAsync(() =>
            {
                if (codedWorkflow is IBeforeAfterRun codedWorkflowWithBeforeAfter)
                {
                    codedWorkflowWithBeforeAfter.Before(new BeforeRunContext()
                    {RelativeFilePath = "GetUserInfo.cs"});
                }

                return System.Threading.Tasks.Task.CompletedTask;
            }, () =>
            {
                ControlledExecution.Run(() =>
                {
                    {
                        var result = codedWorkflow.Execute();
                        newResult = new System.Collections.Generic.Dictionary<string, object>{{"accessToken", result.accessToken}, {"resourceUrl", result.resourceUrl}, {"tenantId", result.tenantId}, {"organizationId", result.organizationId}, };
                    }
                }, cancellationToken);
                return System.Threading.Tasks.Task.FromResult(newResult);
            }, (exception, outArgs) =>
            {
                if (codedWorkflow is IBeforeAfterRun codedWorkflowWithBeforeAfter)
                {
                    codedWorkflowWithBeforeAfter.After(new AfterRunContext()
                    {RelativeFilePath = "GetUserInfo.cs", Exception = exception});
                }

                return System.Threading.Tasks.Task.CompletedTask;
            }), cancellationToken);
            return endContext =>
            {
                accessToken.Set(endContext, (string)result["accessToken"]);
                resourceUrl.Set(endContext, (string)result["resourceUrl"]);
                tenantId.Set(endContext, (string)result["tenantId"]);
                organizationId.Set(endContext, (string)result["organizationId"]);
            };
        }
    }
}