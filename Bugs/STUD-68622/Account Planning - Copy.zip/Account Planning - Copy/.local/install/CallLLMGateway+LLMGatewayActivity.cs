using System;
using System.Activities;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Utils;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Http;
using GetInformationForCompany;
using Newtonsoft.Json;

namespace GetInformationForCompany
{
    public class LLMGatewayActivity : System.Activities.Activity
    {
        public InArgument<string> accessToken { get; set; }

        public InArgument<string> resourceUrl { get; set; }

        public InArgument<string> organizationId { get; set; }

        public InArgument<string> tenantId { get; set; }

        public InArgument<string> systemMessage { get; set; }

        public InArgument<string> userMessage { get; set; }

        public OutArgument<string> response { get; set; }

        public OutArgument<string> error { get; set; }

        public LLMGatewayActivity()
        {
            this.Implementation = () =>
            {
                return new LLMGatewayActivityChild()
                {accessToken = (this.accessToken == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "accessToken") : (InArgument<string>)Argument.CreateReference((Argument)this.accessToken, "accessToken")), resourceUrl = (this.resourceUrl == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "resourceUrl") : (InArgument<string>)Argument.CreateReference((Argument)this.resourceUrl, "resourceUrl")), organizationId = (this.organizationId == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "organizationId") : (InArgument<string>)Argument.CreateReference((Argument)this.organizationId, "organizationId")), tenantId = (this.tenantId == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "tenantId") : (InArgument<string>)Argument.CreateReference((Argument)this.tenantId, "tenantId")), systemMessage = (this.systemMessage == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "systemMessage") : (InArgument<string>)Argument.CreateReference((Argument)this.systemMessage, "systemMessage")), userMessage = (this.userMessage == null ? (InArgument<string>)Argument.CreateReference((Argument)new InArgument<string>(), "userMessage") : (InArgument<string>)Argument.CreateReference((Argument)this.userMessage, "userMessage")), response = (this.response == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "response") : (OutArgument<string>)Argument.CreateReference((Argument)this.response, "response")), error = (this.error == null ? (OutArgument<string>)Argument.CreateReference((Argument)new OutArgument<string>(), "error") : (OutArgument<string>)Argument.CreateReference((Argument)this.error, "error")), };
            };
        }
    }

    internal class LLMGatewayActivityChild : UiPath.CodedWorkflows.AsyncTaskCodedWorkflowActivity
    {
        public InArgument<string> accessToken { get; set; }

        public InArgument<string> resourceUrl { get; set; }

        public InArgument<string> organizationId { get; set; }

        public InArgument<string> tenantId { get; set; }

        public InArgument<string> systemMessage { get; set; }

        public InArgument<string> userMessage { get; set; }

        public OutArgument<string> response { get; set; }

        public OutArgument<string> error { get; set; }

        public System.Collections.Generic.IDictionary<string, object> newResult { get; set; }

        public LLMGatewayActivityChild()
        {
            DisplayName = "LLMGateway";
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, System.Threading.CancellationToken cancellationToken)
        {
            var codedWorkflow = new global::UiPathCSVBuilder.LLMGateway();
            CodedWorkflowHelper.Initialize(codedWorkflow, context);
            var result = await codedWorkflow.Execute(accessToken.Get(context), resourceUrl.Get(context), organizationId.Get(context), tenantId.Get(context), systemMessage.Get(context), userMessage.Get(context));
            newResult = new System.Collections.Generic.Dictionary<string, object>{{"response", result.response}, {"error", result.error}, };
            return endContext =>
            {
                response.Set(endContext, (string)newResult["response"]);
                error.Set(endContext, (string)newResult["error"]);
            };
        }
    }
}