using System.Activities;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Utils;
using ChromeUiBank.Descriptors.ObjectRepository;
using System;
using System.Collections.Generic;
using System.Data;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Orchestrator.Client.Models;
using UiPath.UIAutomationNext.API.Contracts;
using UiPath.UIAutomationNext.API.Models;
using UiPath.UIAutomationNext.Enums;

namespace ChromeUiBank.Descriptors
{
    public class DummyWorkflowActivity : System.Activities.Activity
    {
        public DummyWorkflowActivity()
        {
            this.Implementation = () =>
            {
                return new DummyWorkflowActivityChild()
                {};
            };
        }
    }

    internal class DummyWorkflowActivityChild : CodeActivity
    {
        public DummyWorkflowActivityChild()
        {
            DisplayName = "DummyWorkflow";
        }

        protected override void Execute(CodeActivityContext context)
        {
            var codedWorkflow = new global::ChromeUiBank.Descriptors.DummyWorkflow();
            CodedWorkflowHelper.Initialize(codedWorkflow, context);
            CodedWorkflowHelper.RunWithExceptionHandling(() =>
            {
                if (codedWorkflow is IBeforeAfterRun codedWorkflowWithBeforeAfter)
                {
                    codedWorkflowWithBeforeAfter.Before(new BeforeRunContext()
                    {RelativeFilePath = "DummyWorkflow.cs"});
                }
            }, () =>
            {
                codedWorkflow.Execute();
                return null;
            }, (exception, outArgs) =>
            {
                if (codedWorkflow is IBeforeAfterRun codedWorkflowWithBeforeAfter)
                {
                    codedWorkflowWithBeforeAfter.After(new AfterRunContext()
                    {RelativeFilePath = "DummyWorkflow.cs", Exception = exception});
                }
            });
        }
    }
}