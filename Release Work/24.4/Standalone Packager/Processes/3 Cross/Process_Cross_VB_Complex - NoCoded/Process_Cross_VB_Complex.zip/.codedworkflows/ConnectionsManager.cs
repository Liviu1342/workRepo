using UiPath.CodedWorkflows;
using System;

namespace Process_Cross_VB_Complex
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}